import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from config.config import *
import os
import sys
sys.path.append("..")
def send_email():
    file = report_file()
    sendfile = open(file , 'rb').read()

    att = MIMEText(sendfile,'base64','utf-8')
    att['Content-Type'] = 'application/octet-stream'
    att['Content-Disposition'] = 'attachment; filename="log.txt"'

    msgRoot = MIMEMultipart('related')

    msgRoot['Subject'] = subject
    msgRoot.attach(att)

    smtp = smtplib.SMTP()
    try:
        smtp.connect(smtp_server)
        smtp.login(smpt_user,smpt_password)
        smtp.sendmail(sender,receiver,msgRoot.as_string())
        print("成功")
    except Exception as e:
        print(e)
        print("Error 失败")
    finally:
        smtp.quit()

def report_file():

    #定义文件目录
    result_dit = 'C:\\Users\\cao\\Desktop\\CADMS'

    lists = os.listdir(result_dit)

    #按照时间对文件进行排序
    lists.sort(key=lambda fn: os.path.getatime(result_dit+"\\" + fn))

    # print(lists[-1])

    file = os.path.join(result_dit,lists[-1])

    return file


if __name__ == '__main__':
    send_email()