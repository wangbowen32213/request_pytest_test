import openpyxl
import sys
sys.path.append("../..")
from lib.case_log  import *
from config.config import *
sys.path.append("..")
def work_read_excel(data_file,sheet_name="Sheet1"):
    #返回工作表对象，默认返回第一个工作表
    logging.debug(data_file)
    wb = openpyxl.load_workbook(data_file)
    sheet = wb[sheet_name]
    # sheet = wb.get_sheet_by_name(sheet_name)
    return sheet

def excel_to_list(ws):
    #获取当前工作边所有内容，并返回工作边队列

    row_lists = []
    header = [item.value for item in list(ws.rows)[0]]
    for i in range(1,ws.max_row):
        row_list = [item.value for item in list(ws.rows)[i]]
        dict_row = dict(zip(header,row_list))
        row_lists.append(dict_row)
    return row_lists

def excel_to_column(ws,column_num = 0):
    #获取当前表某一列的所有值，默认获取第一列
    cols = [item.value for item in list(ws.columns)[column_num]]
    logging.debug("excel第%s列值为" % column_num)
    logging.debug(cols)
    return cols

def excel_to_row(ws,row_num = 0):
    #获取当前表某一行的所有值，默认获取第一行
    cols = [item.value for item in list(ws.rows)[row_num]]
    logging.debug("excel第%s行值为" % row_num)
    logging.debug(cols)
    return cols


def get_test_case(data_list,case_num):
    #依据用例名称，获取其余参数值
    #依据用例编号，获取其余参数值（企业零信任接口用例中，部分用例名称重复，修改为依据用例编号获取参数体）
    for case_data in data_list:
        # if case_data["case_name"] == case_name:
        if case_data["case_num"] == case_num:
            logging.debug("编号为%s的用例" % case_num)

            return case_data
    else:
            # logging.debug("无命名为%s的用例" % case_num)
        logging.debug("无编号为%s的用例" % case_num)
        pass
def user_data(data_file,sheet_name):
    ws = work_read_excel(data_file,sheet_name)
    user_data_excel = excel_to_list(ws)

    return user_data_excel


if __name__ == '__main__':

    # sheet = work_read_excel("../data/1.2控制器列表查询接口.xlsx","Sheet1")
    # logging.debug("12312312312")
    # excel_dict = excel_to_list(sheet)
    # excel_column = excel_to_column(sheet)
    # excel_row= excel_to_row(sheet,2)
    # text_case= get_test_case(excel_dict,"test1.2-2")
    #
    # print(text_case)
    # print(excel_row)
    # ws = work_read_excel(os.path.join(data_path, "test.xlsx"), "login")
    # excel_list = excel_to_list(ws)
    # print(excel_list)
    # print(type(excel_list))
    print(user_data())