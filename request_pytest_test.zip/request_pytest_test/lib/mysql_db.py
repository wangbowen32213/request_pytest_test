import pymysql
from config.config import *
import sys
sys.path.append("..")

class Mysql_DB():

    def __init__(self):
        self.conn = pymysql.connect(
            host = hosts,
            port = port,
            user = user,
            password = passwd,
            db = db
        )
        self.cure = self.conn.cursor()

    # def __del__(self):
    #     self.cure.close()
    #     self.conn.close()

    def query(self,sql):
        logging.debug(sql)
        self.cure.execute(sql)
        return self.cure.fetchall()

    def exec(self,sql):
        try:
            logging.debug(sql)
            self.cure.execute(sql)
            self.conn.commit()
        except Exception as e:
            logging.debug("回滚")
            self.conn.rollback()
            print(str(e))

    def check_user(self,sql):
        result = self.query(sql)
        return True if result else False


if __name__ == '__main__':
    sql = 'select * from user'
    aa= Mysql_DB().query(sql)
    print(aa)

