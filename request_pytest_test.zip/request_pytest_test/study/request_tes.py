import json

import requests

url ="http://10.17.1.26:8650/controlCenter/login"

data = '{"account":"%s","passWord":"%s"}' % ("admin","123456")
json_login =json.loads(data)
        # print(type(json))
headers = json.loads('{"Content-Type":"application/json"}')

res = requests.post(url=url,
                    json=json_login,
                    headers=headers)
res_text = res.json()['data']["token"]
print(res_text)
