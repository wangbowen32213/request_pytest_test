import requests

url = "http://120.27.125.223:8099/api/upload/opinion"
url_login = "http://120.27.125.223:8099/api/auth/login"
data = {"username":"test3","password":"123456"}
res = requests.post(url=url_login,data=data)
token = res.json()['data']['token']

headers = {"Authorization":"bearer %s" % token,
            "Accept": "application/json",
          }
file1 = open('20191113.docx', 'rb')

files = {'file':('20191113.docx',file1,'application/vnd.openxmlformats-officedocument.wordprocessingml.document')}

data1  = {"category":"专项工程",
         "name":"载人空间站系统",
         "stage":"工程研制",
         "version":"V20191025-144234(评审前)",
         }

res = requests.post(url=url,headers = headers,data=data1,files=files)
# print(requests.Request('POST', url, headers=headers,data=data,files=files).prepare().body.decode('utf-8'))
print(res.json()["msg"])