import requests

url = "http://47.94.207.202:10998/api/component/uploadFileAction"
cookie = {'PHPSESSID':'8k6sv2oljicd1ic9dpmv9er7so'}
file = {'file':open('20191205103848.png', "rb")}

data = {'type':'datasheet','file':file}
headers = {
            # 'Content-Length':'12259',
           # 'Content-Type':'multipart/form-data; boundary=---------------------------87322552825798',
           # 'Referer':'http://47.94.207.202:10998/admin/component/add'
           }
f1 = open('20191205103848.png', "rb")
files = {'file':('20191205103848.png',f1,'image/png',)}
res = requests.post(url=url,cookies=cookie,data=data,files=files)
print(res.json())