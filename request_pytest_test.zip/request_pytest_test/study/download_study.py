import requests


# url = "http://120.27.125.223:8099/api/models/batch?ids=[4]&version_number=[308]"
# url = "http://120.27.125.223:8099/api/report/down"
url = "http://120.27.125.223:8099/api/auth/login"
data = {"username":"test3","password":"123456"}
res = requests.post(url=url,data=data)
token = res.json()['data']['token']
headers = {"Authorization":"bearer %s" % token}
url = "http://120.27.125.223:8099/api/report/down?type=2&file_path=%2Fdata%2Fwwwroot%2Fassessment%2Fpublic%2Fuploads%2Fzip%2F2.zip&file_name=2.zip&token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xMjAuMjcuMTI1LjIyMzo4MDk5XC9hcGlcL2F1dGhcL2xvZ2luIiwiaWF0IjoxNTc1NDIzNTU3LCJleHAiOjE2NjE4MjM1NTcsIm5iZiI6MTU3NTQyMzU1NywianRpIjoiaEJxU0RCTVBZM1NCODd5NSIsInN1YiI6NDQsInBydiI6ImY2YjcxNTQ5ZGI4YzJjNDJiNzU4MjdhYTQ0ZjAyYjdlZTUyOWQyNGQifQ.9aSxG-UVth95ME9KCw3m1_I8ETp9MFBRiP0YLyqh7_Q"
# url = "http://47.94.207.202:10998/api/CatalogDetailLists/exportLists?catalog_id=26&_=1575445821940"
# headers = {'PHPSESSID':'8k6sv2oljicd1ic9dpmv9er7so','showSlide':'show'}
data = {"type":2,
        "file_path":"/data/wwwroot/assessment/public/uploads/zip/2.zip",
        "file_name":"2.zip",
        "token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xMjAuMjcuMT"
                "I1LjIyMzo4MDk5XC9hcGlcL2F1dGhcL2xvZ2luIiwiaWF0IjoxNTc1NDIzNTU3LCJleHAiOj"
                "E2NjE4MjM1NTcsIm5iZiI6MTU3NTQyMzU1NywianRpIjoiaEJxU0RCTVBZM1NCODd5NSIsInN"
                "1YiI6NDQsInBydiI6ImY2YjcxNTQ5ZGI4YzJjNDJiNzU4MjdhYTQ0ZjAyYjdlZTUyOWQyNGQi"
                "fQ.9aSxG-UVth95ME9KCw3m1_I8ETp9MFBRiP0YLyqh7_Q"
        }
res = requests.get(url=url)



with open("response.zip", "wb") as code:
    for chunk in res.iter_content(chunk_size=1024):
        if chunk:
            code.write(chunk)
