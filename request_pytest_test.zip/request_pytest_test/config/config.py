import logging
import os

toktn = None
prj_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

data_path = os.path.join(prj_path,'data')
test_path = os.path.join(prj_path,'test')

log_file = os.path.join(prj_path, 'log', 'log.txt')  # 更改路径到log目录下
report_file = os.path.join(prj_path, 'report', 'report.html')  # 更改路径到report目录下
#当前文件的上一级的上一级目录



#日志设置
logging.basicConfig(level=logging.DEBUG,  # log level
                    format='[%(asctime)s] %(levelname)s [%(funcName)s: %(filename)s, %(lineno)d] %(message)s',  # log格式
                    datefmt='%Y-%m-%d %H:%M:%S',  # 日期格式
                    filename=log_file,  # 日志输出文件
                    filemode='a')  # 追加模式


#数据库设置

hosts = "127.0.0.1"
# hosts = "localhost"
#地址
port = 3306
#端口
user = "root"
#用户名
passwd = "123456"
#密码
db = "user_admin"
#数据库名称


#邮件设置

smtp_server = 'smtp.163.com'
#发送邮箱服务器
smpt_user = 'wbw19930822@163.com'
#发送邮箱用户名
smpt_password = '322117abc'
#发送邮箱密码
sender = 'wbw19930822@163.com'
#发送邮箱
receiver = "wbw19930822@163.com"
#接收邮箱
subject  = '接口测试报告'
#邮件主题


if __name__ == '__main__':
    # logging.info("hello")
    print(report_file)