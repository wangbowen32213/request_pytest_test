import pytest
import requests
import json
import os
import sys
sys.path.append("../..")
from config.config import *
from lib.read_excel import *
from lib.case_log import *

class TestUserLogin():


    @pytest.fixture(scope='class')
    def class_scope(self):
        ws = work_read_excel(os.path.join(data_path, "test.xlsx"), "User_login")
        excel_list = excel_to_list(ws)
        logging.debug("获取excel全部内容")
        logging.debug(excel_list)
        return excel_list

    @pytest.mark.parametrize('test_name',[
        # "test_user_login_normal",
        "test_user_login_password_wrong"
    ])
    def test_login_1(self,class_scope,test_name):
        dict_request = get_test_case(class_scope,test_name)
        logging.debug("当前用来名称：%s" % test_name)
        url = dict_request.get('url')
        data = json.loads(dict_request.get('data'))
        expect_res = dict_request.get('expect_res')
        res = requests.post(url= url,data=data)
        res_text = res.json()['msg']
        log_case_info(test_name,url,data,expect_res,res_text)
        assert res_text==dict_request["expect_res"]




# if __name__ == '__main__':
#     TestUserLogin().test_login()