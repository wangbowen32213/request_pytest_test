#企业版零信任-控制器列表查询接口
import pytest
import requests
import json
from lib.read_excel import *

from lib.case_log import *
from lib.read_excel import *

class TestUserLogin():
    logging.debug("测试用例日志")
    print(log_file)
    # test_uset_data = [
    #     {"account":"admin","passWord":"1234567","msg":"密码错误"},
    #     {"account":"admin1","passWord":"123456","msg":"用户不存在"},
    #     {"account":"admin","passWord":"123456","msg":"成功"}
    # ]

    # @pytest.mark.parametrize('test_name',[
    #     # "test_user_login_normal",
    #     "test_user_login_password_wrong"
    # ])
    @pytest.mark.parametrize('test_num',user_data(os.path.join(data_path,"test.xlsx"),"login"))
    # @pytest.mark.parametrize('test_num',test_uset_data)
    def test_login_meiya(self,test_num):
        user = test_num["account"]
        password = test_num["passWord"]
        msg = test_num["msg"]
        print(user,password)

        url ="http://10.17.1.26:8650/controlCenter/login"
        # data = json.loads(dict_request.get('data'))
        data = '{"account":"%s","passWord":"%s"}' % (user,password)
        # print(data)
        logging.debug("测试用例日志")
        json_login =json.loads(data)
        # print(type(json))
        headers = json.loads('{"Content-Type":"application/json"}')

        res = requests.post(url=url,
                            json=json_login,
                            headers=headers)
        res_text = res.json()['msg']
        print(res_text)
        assert res_text==msg




if __name__ == '__main__':
    TestUserLogin().test_login_meiya()
    # res = requests.post(url="http://10.17.1.26:8650/controlCenter/login", json={"account":"admin","passWord":"1234567"}, headers={"Content-Type":"application/json"})
    # print(res.json())