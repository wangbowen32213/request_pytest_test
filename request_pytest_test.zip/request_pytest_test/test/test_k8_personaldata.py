import pytest
import requests
import json
import os
import sys
sys.path.append("../..")
from config.config import *
from lib.read_excel import *
from lib.case_log import *


# token = None
class TestUserPersonaldata():


    @pytest.fixture(scope='class')
    def class_scope(self):
        ws = work_read_excel(os.path.join(data_path, "test.xlsx"), "User_login")
        excel_list = excel_to_list(ws)
        logging.debug("获取excel全部内容")
        logging.debug(excel_list)
        url = "http://120.27.125.223:8099/api/auth/login"
        data = {"username":"test3","password":"123456"}
        res = requests.post(url=url,data=data)
        # token = res.json()["data"]["token"]
        global token
        # print(token)
        token = res.json()["data"]["token"]
        # print(token)
        # return excel_list,token
        return excel_list

    @pytest.mark.parametrize('case_name',[

        "test_login_forget_right"
    ])
    @pytest.mark.personaldata
    def test_personaldata_1(self,class_scope,case_name):
        case_list = get_test_case(class_scope,case_name)
        global token
        # print(token)
        url = case_list.get("url")

        data = {"token":token}
        res = requests.get(url=url , params = data)
        res_text = res.json()["msg"]
        expect_res = case_list.get('expect_res')
        log_case_info(case_name=case_name,url=url,data=data,expect_res=expect_res,res_text= res_text)
        assert expect_res == res_text


if __name__ == '__main__':
    pytest.main(["-m","personaldata","-s"])