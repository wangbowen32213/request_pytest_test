import pytest
import requests
import json
import os
import sys
sys.path.append("../..")
from config.config import *
from lib.read_excel import *
from lib.case_log import *

class TestK8Login():

    @pytest.fixture(scope='class')
    def excel_list(self):
        ws = work_read_excel(os.path.join(data_path, "test.xlsx"), "User_login")
        excel_list = excel_to_list(ws)
        # logging.debug("------只执行一次-------")
        return excel_list
    @pytest.mark.k8_login_forget_password
    @pytest.mark.parametrize('case_name',[
        "test_login_wrong_username",
        "test_login_wrong_password",
        "test_login_right",
        #登录校验
        "test_login_forget_wrong_password",
        "test_login_forget_wrong_pwd_answer",
        "test_login_forget_wrong_pwd_problem",
        "test_login_forget_wrong_username",
        "test_login_forget_right"
        #忘记密码校验
    ])
    def test_login2_1(self,excel_list,case_name):
        # case_name = "test_login_forget_password"
        case_data = get_test_case(excel_list,case_name)
        url = case_data.get('url')
        data = json.loads(case_data.get('data'))
        except_res = case_data.get('expect_res')
        res = requests.post(url=url,data=data)
        res_text = res.json()['msg']
        log_case_info(case_name,url,data,except_res,res_text)


        assert res_text==except_res



# if __name__ == '__main__':
#     TestUserLogin().test_login()