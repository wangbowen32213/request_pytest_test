from meiya_pico.test_getControlList import *
sys.path.append("../..")
import pytest
if __name__ == '__main__':
    # pytest.main(["-s","-m","personaldata","--html=%s" % report_file])
    # pytest.main(["-s","-m","test/test_getControlList.py","--html=../report.html"])
    pytest.main(["-s","-v","meiya_pico/test_getControlList.py"])