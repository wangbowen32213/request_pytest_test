#企业版零信任-控制器列表查询接口
import pytest
import requests
import json
import os
import sys
sys.path.append("../..")
from config.config import *
from lib.read_excel import *


class TestUserLogin():
    @pytest.fixture(scope='class')
    def excel_list(self):
        url = "http://10.17.1.26:8650/controlCenter/login"
        # data = json.loads(dict_request.get('data'))
        data = '{"account":"%s","passWord":"%s"}' % ("admin", "123456")
        # print(data)
        # logging.debug("测试用例日志")
        json_login = json.loads(data)
        # print(type(json))
        headers = json.loads('{"Content-Type":"application/json"}')

        res = requests.post(url=url,
                            json=json_login,
                            headers=headers)
        res_text = res.json()['data']["token"]
        return res_text
    @pytest.mark.parametrize('test_num',user_data(os.path.join(data_path,"1.2控制器列表查询接口.xlsx"),"Sheet1"))
    def test_login_meiya(self,test_num,excel_list):

        # url = dict_request.get('url')
        url ="http://10.17.1.26:8650/controlCenter/control/getControlList"
        # data = json.loads(dict_request.get('data'))
        nodeSign = test_num['nodeSign']
        nodeName = test_num['nodeName']
        poolSign = test_num['poolSign']
        poolName = test_num['poolName']
        isAvailed = test_num['isAvailed']
        nodeIp = test_num['nodeIp']
        nodeMac = test_num['nodeMac']
        startTime = test_num['startTime']
        endTime = test_num['endTime']
        pageNum = test_num['pageNum']
        pageSize = test_num['pageSize']
        expect = test_num['expect']
        case_name = test_num['case_name']
        data = '{"nodeSign":%s,"nodeName":%s,"poolSign":%s,"poolName":%s,"isAvailed":%s,' \
               '"nodeIp":%s,"nodeMac":%s,"startTime":%s,"endTime":%s,"pageNum":%s,"pageSize":%s}' \
               % (nodeSign, nodeName, poolSign, poolName, isAvailed, nodeIp, nodeMac, startTime, endTime, pageNum,pageSize)
        json_data =json.loads(data)
        # print(type(json))
        headers = json.loads('{"Content-Type":"application/json","Authorization":"Bearer %s"}' % excel_list)

        res = requests.post(url=url,
                            json=json_data,
                            headers=headers)
        res_text = '"code":"%s"' % res.json()['code']
        # print(res_text)
        # log_case_info(test_num,url,json_data,expect,res_text)

        logging.debug(case_name)
        assert res_text == expect




if __name__ == '__main__':
    TestUserLogin().test_login_meiya()
    # res = requests.post(url="http://10.17.1.26:8650/controlCenter/login", json={"account":"admin","passWord":"1234567"}, headers={"Content-Type":"application/json"})
    # print(res.json())